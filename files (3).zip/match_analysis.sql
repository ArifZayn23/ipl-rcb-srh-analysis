-- ============================================================
--  IPL 2026 | RCB vs SRH | SQL Analysis Queries
--  Database  : SQLite / PostgreSQL compatible
--  Author    : [Your Name]
-- ============================================================

-- ─────────────────────────────────────────
-- TABLE SETUP (run once to import CSV)
-- ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS deliveries (
    match_id        INTEGER,
    date            TEXT,
    venue           TEXT,
    batting_team    TEXT,
    bowling_team    TEXT,
    over            INTEGER,
    ball            INTEGER,
    batsman         TEXT,
    bowler          TEXT,
    runs            INTEGER,
    extras          INTEGER,
    wicket          INTEGER,
    dismissal_type  TEXT,
    fielder         TEXT
);

-- ─────────────────────────────────────────
-- Q1: MATCH SCORECARD SUMMARY
-- ─────────────────────────────────────────
SELECT
    batting_team                              AS team,
    SUM(runs) + SUM(extras)                  AS total_score,
    SUM(wicket)                              AS wickets_lost,
    ROUND(CAST(SUM(runs) + SUM(extras) AS REAL) / 20, 2) AS run_rate,
    SUM(CASE WHEN runs = 4 THEN 1 ELSE 0 END) AS fours,
    SUM(CASE WHEN runs = 6 THEN 1 ELSE 0 END) AS sixes
FROM deliveries
GROUP BY batting_team
ORDER BY total_score DESC;


-- ─────────────────────────────────────────
-- Q2: TOP BATSMEN (min 10 balls)
-- ─────────────────────────────────────────
SELECT
    batting_team,
    batsman,
    SUM(runs)                               AS runs,
    COUNT(ball)                             AS balls_faced,
    ROUND(CAST(SUM(runs) AS REAL) / COUNT(ball) * 100, 1) AS strike_rate,
    SUM(CASE WHEN runs = 4 THEN 1 ELSE 0 END) AS fours,
    SUM(CASE WHEN runs = 6 THEN 1 ELSE 0 END) AS sixes
FROM deliveries
GROUP BY batting_team, batsman
HAVING balls_faced >= 10
ORDER BY runs DESC
LIMIT 10;


-- ─────────────────────────────────────────
-- Q3: BOWLING PERFORMANCE
-- ─────────────────────────────────────────
SELECT
    bowling_team,
    bowler,
    COUNT(DISTINCT over)                    AS overs_bowled,
    SUM(runs)                               AS runs_conceded,
    SUM(wicket)                             AS wickets,
    ROUND(CAST(SUM(runs) AS REAL) /
          COUNT(ball) * 6, 2)               AS economy_rate
FROM deliveries
GROUP BY bowling_team, bowler
ORDER BY wickets DESC, economy_rate ASC;


-- ─────────────────────────────────────────
-- Q4: PHASE-WISE RUN RATE COMPARISON
-- ─────────────────────────────────────────
SELECT
    batting_team,
    CASE
        WHEN over BETWEEN 1  AND 6  THEN 'Powerplay (1-6)'
        WHEN over BETWEEN 7  AND 15 THEN 'Middle (7-15)'
        ELSE                              'Death (16-20)'
    END                                     AS phase,
    SUM(runs)                               AS runs,
    COUNT(ball)                             AS balls,
    ROUND(CAST(SUM(runs) AS REAL) / COUNT(ball) * 6, 2) AS run_rate
FROM deliveries
GROUP BY batting_team, phase
ORDER BY batting_team, MIN(over);


-- ─────────────────────────────────────────
-- Q5: OVER-BY-OVER SCORING
-- ─────────────────────────────────────────
SELECT
    batting_team,
    over,
    SUM(runs) + SUM(extras)                 AS runs_in_over,
    SUM(wicket)                             AS wickets_in_over
FROM deliveries
GROUP BY batting_team, over
ORDER BY batting_team, over;


-- ─────────────────────────────────────────
-- Q6: DISMISSAL BREAKDOWN
-- ─────────────────────────────────────────
SELECT
    batting_team,
    dismissal_type,
    COUNT(*)                                AS count,
    ROUND(COUNT(*) * 100.0 /
        SUM(COUNT(*)) OVER (PARTITION BY batting_team), 1) AS pct
FROM deliveries
WHERE wicket = 1
GROUP BY batting_team, dismissal_type
ORDER BY batting_team, count DESC;


-- ─────────────────────────────────────────
-- Q7: BOUNDARY BALLS (4s and 6s per over)
-- ─────────────────────────────────────────
SELECT
    batting_team,
    over,
    SUM(CASE WHEN runs = 4 THEN 1 ELSE 0 END) AS fours,
    SUM(CASE WHEN runs = 6 THEN 1 ELSE 0 END) AS sixes,
    SUM(CASE WHEN runs IN (4,6) THEN 1 ELSE 0 END) AS total_boundaries
FROM deliveries
GROUP BY batting_team, over
ORDER BY batting_team, over;


-- ─────────────────────────────────────────
-- Q8: PARTNERSHIP IMPACT
--     (runs scored per bowling phase by bowler)
-- ─────────────────────────────────────────
SELECT
    bowling_team,
    bowler,
    CASE
        WHEN over BETWEEN 1  AND 6  THEN 'Powerplay'
        WHEN over BETWEEN 7  AND 15 THEN 'Middle'
        ELSE                              'Death'
    END                                     AS phase,
    SUM(runs)                               AS runs_given,
    SUM(wicket)                             AS wickets
FROM deliveries
GROUP BY bowling_team, bowler, phase
ORDER BY bowling_team, bowler, MIN(over);
