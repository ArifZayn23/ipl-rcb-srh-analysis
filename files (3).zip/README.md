# 🏏 IPL 2026 | RCB vs SRH Match Analysis

> **A complete data analysis project** on the RCB vs SRH IPL match played on 22 May 2026  
> at M. Chinnaswamy Stadium, Bengaluru.

---

## 📌 Match Result

| Team | Score | Result |
|------|-------|--------|
| **RCB** 🔴 | **214 / 9** (20 overs) | ✅ **Won by 12 runs** |
| SRH 🟠 | 202 / 10 (19.5 overs) | ❌ Lost |

---

## 🎯 Project Overview

This project demonstrates end-to-end data analysis of a T20 cricket match using:
- **Python** — data wrangling, metrics computation, visualizations
- **SQL** — structured queries for scorecards, bowling stats, phase analysis
- **Excel / Power BI** — ready-to-import CSV for dashboards

It is designed as a **portfolio project** to showcase skills in:
- Data cleaning and feature engineering
- Aggregation and grouping logic
- Storytelling through charts and insights

---

## 📁 Project Structure

```
ipl-rcb-srh-analysis/
│
├── data/
│   ├── rcb_srh_scorecard.csv       # Ball-by-ball raw data
│   └── rcb_vs_srh_analysis.png     # Auto-generated dashboard
│
├── sql/
│   └── match_analysis.sql          # 8 SQL queries with comments
│
├── analysis.py                     # Main Python script
├── requirements.txt                # Python dependencies
└── README.md
```

---

## 📊 Key Insights

1. **Rajat Patidar** was the Player of the Match — scored **98*** off 48 balls (SR: 204)
2. **RCB's powerplay** was dominant — RR 10.5 vs SRH's 9.2
3. **Wanindu Hasaranga** was RCB's top bowler — 3 wickets at economy 6.5
4. **Washington Sundar** fought hard for SRH — 62 off 43 balls
5. **60% of wickets** were caught — RCB's fielding was sharp
6. SRH needed **37 off last 2 overs** — too steep a target

---

## 🚀 How to Run

### Python
```bash
# Install dependencies
pip install pandas matplotlib seaborn

# Run analysis
python analysis.py
```

### SQL
```bash
# SQLite example
sqlite3 ipl.db
.mode csv
.import data/rcb_srh_scorecard.csv deliveries
.read sql/match_analysis.sql
```

### Excel / Power BI
- Open `data/rcb_srh_scorecard.csv` directly in Excel or Power BI Desktop
- Use **Get Data > CSV** and apply the SQL queries as Power Query steps

---

## 📈 Visualizations Generated

| Chart | Description |
|-------|-------------|
| Run Progression | Cumulative score curve for both teams |
| Runs Per Over | Side-by-side bar chart per over |
| Phase-wise RR | Powerplay / Middle / Death run rate comparison |
| Top Batsmen | Horizontal bar by runs scored |
| Dismissal Types | Pie chart of how wickets fell |
| Economy vs Wickets | Scatter plot for bowler effectiveness |

---

## 🛠 Tech Stack

![Python](https://img.shields.io/badge/Python-3.10+-blue?logo=python)
![Pandas](https://img.shields.io/badge/Pandas-2.x-green?logo=pandas)
![Matplotlib](https://img.shields.io/badge/Matplotlib-3.x-orange)
![SQL](https://img.shields.io/badge/SQL-SQLite-lightgrey?logo=sqlite)
![Excel](https://img.shields.io/badge/Excel%20%2F%20Power%20BI-Ready-success?logo=microsoft-excel)

---

## 👤 Author

**[Your Name]**  
Junior Data Analyst | Cricket Analytics Enthusiast  
📧 your.email@example.com  
🔗 [LinkedIn](https://linkedin.com/in/yourprofile) | [GitHub](https://github.com/yourusername)

---

## ⭐ If you found this useful, give it a star!
